package br.unicesumar.livro;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/livro")
public class LivroController {

	@Autowired
	LivroRepository repo;
	
	@GetMapping
	public ResponseEntity<List<Livro>> obterTodos(){
		return ResponseEntity.ok().body(repo.findAll());
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<Livro> obterPeloId(@PathVariable String id){
		Livro novo = repo.findOne(id);
		
		if(novo == null) {
			return ResponseEntity.notFound().build();
		}
		
		return ResponseEntity.ok().body(repo.findOne(id));
	}
	
	@PostMapping
	public ResponseEntity<String> incluir(@RequestBody Livro novoLivro){
		repo.save(novoLivro);
		return ResponseEntity.ok().body(novoLivro.getId());
	}
	
	@PutMapping
	public ResponseEntity<String> alterar(@RequestBody Livro novoLivro){
		repo.save(novoLivro);
		return ResponseEntity.ok().body(novoLivro.getId());
	}
	
	
	@DeleteMapping("/{id}")
	public ResponseEntity<Void> excluir(@PathVariable String id){
		repo.delete(id);
		return ResponseEntity.ok().build();
	}
}
