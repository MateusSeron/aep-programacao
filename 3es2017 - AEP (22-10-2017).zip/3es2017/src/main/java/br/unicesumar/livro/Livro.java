package br.unicesumar.livro;

import java.util.UUID;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Livro {
	@Id
	private String id;
	private String titulo;
	private int paginas;
	private String autor;
	
	public Livro() {
		this.id = UUID.randomUUID().toString();
	}

	public String getId() {
		return id;
	}

	public String getTitulo() {
		return titulo;
	}

	public int getPaginas() {
		return paginas;
	}

	public String getAutor() {
		return autor;
	}
	
	
	
}
