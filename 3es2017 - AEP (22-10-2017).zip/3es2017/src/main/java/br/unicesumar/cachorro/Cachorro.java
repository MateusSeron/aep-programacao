package br.unicesumar.cachorro;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Cachorro {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private Long id;
	private String raca;
	private String cor;
	private boolean pedigree;
	
	public Cachorro() {
		
	}

	public Long getId() {
		return id;
	}

	public String getRaca() {
		return raca;
	}

	public String getCor() {
		return cor;
	}

	public boolean isPedigree() {
		return pedigree;
	}
	
	
	
}
