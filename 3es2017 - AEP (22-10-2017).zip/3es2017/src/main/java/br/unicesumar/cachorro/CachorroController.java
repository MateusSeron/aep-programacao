package br.unicesumar.cachorro;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/cachorro")
public class CachorroController {
	
	@Autowired
	CachorroRepository repo;
	
	@GetMapping
	public ResponseEntity<List<Cachorro>> obterTodos(){
		return ResponseEntity.ok().body(repo.findAll());
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<Cachorro> obterPeloId(@PathVariable Long id){
		Cachorro novo = repo.findOne(id);
		
		if(novo == null) {
			return ResponseEntity.notFound().build();
		}
		return ResponseEntity.ok().body(repo.findOne(id));
	}
	
	@PostMapping
	public ResponseEntity<Long> incluir(@RequestBody Cachorro novoCachorro){
		repo.save(novoCachorro);
		return ResponseEntity.ok().body(novoCachorro.getId());
	}
	
	@PutMapping
	public ResponseEntity<Long> alterar (@RequestBody Cachorro novoCachorro){
		repo.save(novoCachorro);
		return ResponseEntity.ok().body(novoCachorro.getId());
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<Void> excluir(@PathVariable Long id){
		repo.delete(id);
		return ResponseEntity.ok().build();
	}
	
}
