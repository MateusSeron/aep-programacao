package br.unicesumar.tenis;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Tenis {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	private String modelo;
	private String cor;
	private int tamanho;
	
	public Tenis() {
		
	}

	public Integer getId() {
		return id;
	}

	public String getModelo() {
		return modelo;
	}

	public String getCor() {
		return cor;
	}

	public int getTamanho() {
		return tamanho;
	}
	
	
	
}
