package br.unicesumar.tenis;

import org.springframework.data.jpa.repository.JpaRepository;

public interface TenisRepository extends JpaRepository<Tenis, Integer>{

}
