package br.unicesumar.tenis;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/tenis")
public class TenisController {

	@Autowired
	TenisRepository repo;
	
	@GetMapping
	public ResponseEntity<List<Tenis>> obterTodos(){
		return ResponseEntity.ok().body(repo.findAll());
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<Tenis> obterPeloId(@PathVariable Integer id){
		Tenis novo = repo.findOne(id);
		
		if (novo == null) {
			return ResponseEntity.notFound().build();
		}
		return ResponseEntity.ok().body(repo.findOne(id));
	}
	
	@PostMapping
	public ResponseEntity<Integer> incluir(@RequestBody Tenis novoTenis){
		repo.save(novoTenis);
		return ResponseEntity.ok().body(novoTenis.getId());
	}
	
	@PutMapping
	public ResponseEntity<Integer> alterar(@RequestBody Tenis novoTenis){
		repo.save(novoTenis);
		return ResponseEntity.ok().body(novoTenis.getId());
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<Void> excluir(@PathVariable Integer id){
		repo.delete(id);
		return ResponseEntity.ok().build();
	}
}
