package br.unicesumar.celular;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CelularRepository extends JpaRepository<Celular, Integer>{

}
