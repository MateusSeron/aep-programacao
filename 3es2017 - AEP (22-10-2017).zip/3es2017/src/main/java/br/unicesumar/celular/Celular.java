package br.unicesumar.celular;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Celular {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private String marca;
	private String modelo;
	private double valor;
	private String cor;
	
	public Celular() {
		
	}

	public int getId() {
		return id;
	}

	public String getMarca() {
		return marca;
	}

	public String getModelo() {
		return modelo;
	}

	public double getValor() {
		return valor;
	}

	public String getCor() {
		return cor;
	}
	
	
}
