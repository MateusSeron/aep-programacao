package br.unicesumar.celular;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/celular")
public class CelularController {

	@Autowired
	CelularRepository repo;
	
	@GetMapping
	public ResponseEntity<List<Celular>> obterTodos(){
		return ResponseEntity.ok().body(repo.findAll());
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<Celular> obterPeloId(@PathVariable int id){
		Celular novoCelular = repo.findOne(id);
		
		if(novoCelular == null) {
			return ResponseEntity.notFound().build();
		}
		return ResponseEntity.ok().body(repo.findOne(id));
	}
	
	@PostMapping
	public ResponseEntity<Integer> incluir(@RequestBody Celular novoCelular){
		repo.save(novoCelular);
		return ResponseEntity.ok().body(novoCelular.getId());
	}
	
	@PutMapping
	public ResponseEntity<Integer> alterar(@RequestBody Celular novoCelular){
		repo.save(novoCelular);
		return ResponseEntity.ok().body(novoCelular.getId());
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<Void> excluir(@PathVariable int id){
		repo.delete(id);
		return ResponseEntity.ok().build();
	}
}
