package br.unicesumar.camiseta;

import java.util.UUID;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Camiseta {
	@Id
	private String id;
	private String tamanho;
	private String cor;
	private float preco;
	
	public Camiseta() {
		this.id = UUID.randomUUID().toString();
	}

	public String getId() {
		return id;
	}

	public String getTamanho() {
		return tamanho;
	}

	public String getCor() {
		return cor;
	}

	public float getPreco() {
		return preco;
	}
	
	
}
