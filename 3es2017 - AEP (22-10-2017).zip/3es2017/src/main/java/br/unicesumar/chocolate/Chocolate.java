package br.unicesumar.chocolate;

import java.util.UUID;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Chocolate {

	@Id
	private String id;
	private String marca;
	private int gramas;
	private String tipo;
	
	public Chocolate() {
		this.id = UUID.randomUUID().toString();
	}

	public String getId() {
		return id;
	}

	public String getMarca() {
		return marca;
	}

	public int getGramas() {
		return gramas;
	}

	public String getTipo() {
		return tipo;
	}
	
	
	
}
