package br.unicesumar.chocolate;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ChocolateRepository extends JpaRepository<Chocolate, String>{

}
