package br.unicesumar.moto;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/moto")
public class MotoController {
	
	@Autowired
	public MotoRepository repo;
	
	@GetMapping
	public ResponseEntity<List<Moto>> obterTodas(){
		return ResponseEntity.ok().body(repo.findAll());
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<Moto> obterPeloId(@PathVariable Integer id){
		Moto moto = repo.findOne(id);
		
		if(moto == null) {
			return ResponseEntity.notFound().build();
		}
		return ResponseEntity.ok().body(repo.findOne(id));
	}
	
	@PostMapping
	public ResponseEntity<Integer> incluir(@RequestBody Moto novaMoto){
		repo.save(novaMoto);
		return ResponseEntity.ok().body(novaMoto.getId());
	}
	
	@PutMapping
	public ResponseEntity<Integer> alterar(@RequestBody Moto novaMoto){
		repo.save(novaMoto);
		return ResponseEntity.ok().body(novaMoto.getId());

	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<Void> excluir(@PathVariable Integer id){
		repo.delete(id);
		return ResponseEntity.ok().build();
	}
}
