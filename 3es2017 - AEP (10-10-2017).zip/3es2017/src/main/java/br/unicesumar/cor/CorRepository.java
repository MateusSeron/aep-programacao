package br.unicesumar.cor;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CorRepository extends JpaRepository<Cor, String> {
	
}
