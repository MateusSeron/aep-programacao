package br.unicesumar.moto;

import org.springframework.data.jpa.repository.JpaRepository;

public interface MotoRepository extends JpaRepository<Moto, Integer>{

}
