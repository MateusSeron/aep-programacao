package br.unicesumar.moto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Moto {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private Integer id;
	private String placa;
	private int cilindradas;
	private String cor;
	
	public Moto() {
		
	}

	public Integer getId() {
		return id;
	}

	public String getPlaca() {
		return placa;
	}

	public int getCilindradas() {
		return cilindradas;
	}

	public String getCor() {
		return cor;
	}
	
	
}
