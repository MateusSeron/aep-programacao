package br.unicesumar.notafiscal;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class NotaFiscal {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	private String data;
	private float valorTotal;
	private String fornecedor;
	
	public NotaFiscal() {
	
	}

	public long getId() {
		return id;
	}

	public String getData() {
		return data;
	}

	public float getValorTotal() {
		return valorTotal;
	}

	public String getFornecedor() {
		return fornecedor;
	}
	
}
