package br.unicesumar.relogio;

import java.util.UUID;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Relogio {
	@Id
	private String id;
	private String pulseira;
	private String cor;
	private String tipo;
	
	public Relogio() {
		this.id = UUID.randomUUID().toString();
	}

	public String getId() {
		return id;
	}

	public String getPulseira() {
		return pulseira;
	}

	public String getCor() {
		return cor;
	}

	public String getTipo() {
		return tipo;
	}
	
	
}
