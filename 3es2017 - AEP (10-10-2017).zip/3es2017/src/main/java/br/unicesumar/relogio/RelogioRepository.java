package br.unicesumar.relogio;

import org.springframework.data.jpa.repository.JpaRepository;

public interface RelogioRepository extends JpaRepository<Relogio, String>{

}
