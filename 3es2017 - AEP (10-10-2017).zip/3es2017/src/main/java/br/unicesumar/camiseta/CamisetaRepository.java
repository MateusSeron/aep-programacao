package br.unicesumar.camiseta;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CamisetaRepository extends JpaRepository<Camiseta, String>{

}
