package br.unicesumar.teste;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.embedded.LocalServerPort;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

import br.unicesumar.livro.Livro;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
@TestPropertySource(locations = { "classpath:application-test.properties" })
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ApplicationTest {
	@LocalServerPort
	private int port;

	@Autowired
	private TestRestTemplate restTemplate;

	@Test
	public void contextLoads() {
	}

	@Test
	public void t1_obtencao_de_livros_retorna_lista_vazia() throws Exception {

		ResponseEntity<? extends List<Livro>> resp = this.restTemplate
				.getForEntity("http://localhost:" + port + "/livros", (Class<? extends List<Livro>>) List.class);
		assertThat(resp.getBody().size()).isEqualTo(0);
		assertThat(resp.getStatusCode()).isEqualTo(HttpStatus.OK);
	}

	@Test
	public void t2_criar_livro_retorna_id() throws Exception {
		Livro l = new Livro("Teste2", 2);
		ResponseEntity<String> resp = this.restTemplate.postForEntity("http://localhost:" + port + "/livros", l,
				String.class);
		assertThat(resp.getBody()).isEqualTo(l.getId());
		assertThat(resp.getStatusCode()).isEqualTo(HttpStatus.OK);
	}

	@Test
	public void t3_obtencao_de_livro_por_id() throws Exception {
		Livro l = new Livro("Teste3", 3);
		this.restTemplate.postForEntity("http://localhost:" + port + "/livros", l, String.class);

		ResponseEntity<Livro> resp = this.restTemplate.getForEntity("http://localhost:" + port + "/livros/" + l.getId(),
				Livro.class);

		Livro r = resp.getBody();
		assertThat(r.getId()).isEqualTo(l.getId());
		assertThat(r.getTitulo()).isEqualTo(l.getTitulo());
		assertThat(r.getNumeroDePaginas()).isEqualTo(l.getNumeroDePaginas());
		assertThat(resp.getStatusCode()).isEqualTo(HttpStatus.OK);
	}

	@Test
	public void t4_deleta_livro_por_id() throws Exception {
		Livro l = new Livro("Teste4", 4);
		this.restTemplate.postForEntity("http://localhost:" + port + "/livros", l, String.class);

		ResponseEntity<Void> resp = restTemplate.exchange("http://localhost:" + port + "/livros/" + l.getId(),
				HttpMethod.DELETE, null, Void.class, new Long(1));

		assertThat(resp.getStatusCode()).isEqualTo(HttpStatus.OK);
	}

	@Test
	public void t5_alterar_dados_livro() throws Exception {
		Livro l = new Livro("abcde", 111);
		ResponseEntity<String> resp = this.restTemplate.postForEntity("http://localhost:" + port + "/livros", l,
				String.class);

		Livro l2 = new Livro(l.getId(), "Livro5", 5);
		HttpEntity<Livro> httpEntity = new HttpEntity<Livro>(l2, null);
		ResponseEntity<String> resp2 = restTemplate.exchange("http://localhost:" + port + "/livros", HttpMethod.PUT,
				httpEntity, String.class, new Long(1));
		assertThat(resp.getBody()).isEqualTo(l2.getId());
		assertThat(resp.getStatusCode()).isEqualTo(HttpStatus.OK);

		ResponseEntity<Livro> resp3 = this.restTemplate
				.getForEntity("http://localhost:" + port + "/livros/" + l.getId(), Livro.class);
		Livro r = resp3.getBody();
		assertThat(r.getId()).isEqualTo(l2.getId());
		assertThat(r.getTitulo()).isEqualTo(l2.getTitulo());
		assertThat(r.getNumeroDePaginas()).isEqualTo(l2.getNumeroDePaginas());
		assertThat(resp.getStatusCode()).isEqualTo(HttpStatus.OK);
	}

	@Test
	public void t6_obter_todos_livros() throws Exception {
		ResponseEntity<? extends List<Livro>> resp = this.restTemplate
				.getForEntity("http://localhost:" + port + "/livros", (Class<? extends List<Livro>>) List.class);
		assertThat(resp.getBody().size()).isEqualTo(3);
		assertThat(resp.getStatusCode()).isEqualTo(HttpStatus.OK);
	}

}
