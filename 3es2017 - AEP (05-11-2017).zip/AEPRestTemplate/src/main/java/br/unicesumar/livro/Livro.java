package br.unicesumar.livro;

import java.util.UUID;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Livro {
	@Id
	private String id;
	private String titulo;
	private Integer numeroDePaginas;

	public Livro() {
		this.id = UUID.randomUUID().toString();
	}

	public Livro(String titulo, Integer numeroDePaginas) {
		this();
		this.titulo = titulo;
		this.numeroDePaginas = numeroDePaginas;
	}

	public Livro(String id, String titulo, Integer numeroDePaginas) {
		this.id = id;
		this.titulo = titulo;
		this.numeroDePaginas = numeroDePaginas;
	}

	public String getId() {
		return id;
	}

	public String getTitulo() {
		return titulo;
	}

	public Integer getNumeroDePaginas() {
		return numeroDePaginas;
	}
}
