package br.unicesumar.livro;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/livros")
public class LivroController {

	@Autowired
	private LivroRepository repo;

	@GetMapping
	public ResponseEntity<List<Livro>> obterTodas() {
		return ResponseEntity.ok(repo.findAll());
	}

	@PostMapping
	public ResponseEntity<String> adicionar(@RequestBody Livro novo) {
		repo.save(novo);
		return ResponseEntity.ok(novo.getId());
	}

	@PutMapping
	public ResponseEntity<String> alterar(@RequestBody Livro novo) {
		repo.save(novo);
		return ResponseEntity.ok().body(novo.getId());
	}

	@GetMapping("/{id}")
	public ResponseEntity<Livro> obterPorId(@PathVariable String id) {
		Livro livro = repo.findOne(id);
		if (livro == null) {
			return ResponseEntity.notFound().build();
		} else {
			return ResponseEntity.ok().body(livro);
		}
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Void> excluirPorId(@PathVariable String id) {
		if (!repo.exists(id) == true) {
			return ResponseEntity.notFound().build();
		}
		repo.delete(id);
		return ResponseEntity.ok().build();
	}

}
